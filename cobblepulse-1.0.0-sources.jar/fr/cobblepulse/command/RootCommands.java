package fr.cobblepulse.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.tree.LiteralCommandNode;
import fr.cobblepulse.CobblePulse;
import fr.cobblepulse.clan.ClanCommands;
import fr.cobblepulse.clan.ClanManager;
import fr.cobblepulse.config.Cfg;
import fr.cobblepulse.core.Msg;
import fr.cobblepulse.core.Perms;
import fr.cobblepulse.league.LeagueCommands;
import fr.cobblepulse.league.LeagueManager;
import fr.cobblepulse.menu.MainMenu;
import fr.cobblepulse.profile.ProfileGui;
import fr.cobblepulse.storage.DataService;
import fr.cobblepulse.storage.PlayerDataManager;
import fr.cobblepulse.tournament.TournamentCommands;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** Enregistrement de toutes les commandes du mod. */
public final class RootCommands {
    private RootCommands() {}

    public static void register(CommandDispatcher<class_2168> d) {
        LiteralCommandNode<class_2168> root = d.register(method_9247("cobblepulse").requires(Perms.playerReq(Perms.MENU))
                .executes(ctx -> {
                    MainMenu.open(ctx.getSource().method_9207());
                    return 1;
                })
                .then(method_9247("reload").requires(Perms.adminReq(Perms.ADMIN_RELOAD)).executes(ctx -> {
                    Cfg.loadAll();
                    Msg.send(ctx.getSource(), "general.reloaded", "tiers", Cfg.TIERS.size());
                    return 1;
                }))
                .then(method_9247("selftest").requires(Perms.adminReq(Perms.ADMIN))
                        .executes(ctx -> SelfTest.basic(ctx.getSource()))
                        .then(method_9247("battle").executes(ctx -> SelfTest.battle(ctx.getSource())))
                        .then(method_9247("tournament").executes(ctx -> SelfTest.tournament(ctx.getSource())))
                        .then(method_9247("persisted").executes(ctx -> SelfTest.persisted(ctx.getSource())))
                        .then(method_9247("report").executes(ctx -> SelfTest.report(ctx.getSource()))))
                .then(method_9247("payinfluence").requires(Perms.adminReq(Perms.ADMIN)).executes(ctx -> {
                    ClanManager.payInfluence();
                    Msg.send(ctx.getSource(), "general.influence_paid");
                    return 1;
                }))
                .then(method_9247("season").requires(Perms.adminReq(Perms.ADMIN_SEASON))
                        .then(method_9247("reset").then(method_9244("cible", StringArgumentType.word())
                                .suggests((c, b) -> class_2172.method_9265(List.of("badges", "league", "clans", "all"), b))
                                .executes(ctx -> {
                                    Msg.send(ctx.getSource(), "general.season_confirm", "target", StringArgumentType.getString(ctx, "cible"));
                                    return 1;
                                })
                                .then(method_9247("confirm").executes(ctx -> seasonReset(ctx.getSource(), StringArgumentType.getString(ctx, "cible"))))))));
        d.register(method_9247("cp").requires(Perms.playerReq(Perms.MENU)).executes(ctx -> {
            MainMenu.open(ctx.getSource().method_9207());
            return 1;
        }).redirect(root));

        d.register(method_9247("profile").requires(Perms.playerReq(Perms.PROFILE_VIEW))
                .executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    ProfileGui.open(p, p.method_5667(), p.method_7334().getName());
                    return 1;
                })
                .then(method_9244("joueur", StringArgumentType.word()).suggests(Cmd.ONLINE).executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    return Cmd.profile(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), gp -> ProfileGui.open(p, gp.getId(), gp.getName())) ? 1 : 0;
                })));

        LeagueCommands.register(d);
        ClanCommands.register(d);
        TournamentCommands.register(d);
    }

    private static int seasonReset(class_2168 src, String target) {
        boolean all = target.equals("all");
        if (all || target.equals("league")) LeagueManager.resetAll();
        if (all || target.equals("clans")) ClanManager.resetInfluence();
        if (all || target.equals("badges")) {
            for (var d : PlayerDataManager.cached()) {
                d.badges.clear();
                d.badgeCooldowns.clear();
                d.placeCooldownUntil = 0;
                PlayerDataManager.save(d);
            }
            DataService.async(s -> s.listPlayers()).thenAccept(list -> DataService.main(() -> {
                for (UUID u : list) {
                    PlayerDataManager.modify(u, null, d -> {
                        d.badges.clear();
                        d.badgeCooldowns.clear();
                        d.placeCooldownUntil = 0;
                    });
                }
                CobblePulse.LOG.info("[CobblePulse] Remise a zero des badges : {} dossiers", list.size());
            }));
        }
        Msg.broadcast("general.season_reset", "target", target);
        return 1;
    }
}
