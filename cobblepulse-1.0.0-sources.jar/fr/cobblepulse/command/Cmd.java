package fr.cobblepulse.command;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import fr.cobblepulse.core.Msg;
import fr.cobblepulse.league.LeagueManager;
import fr.cobblepulse.league.PokeType;
import fr.cobblepulse.storage.PlayerDataManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_2168;
import net.minecraft.class_2172;

/** Utilitaires partages par les commandes. */
public final class Cmd {
    public static final SuggestionProvider<class_2168> ONLINE =
            (ctx, b) -> class_2172.method_9265(ctx.getSource().method_9262(), b);

    public static final SuggestionProvider<class_2168> POSTS = (ctx, b) -> {
        List<String> ids = new ArrayList<>();
        LeagueManager.posts().forEach(p -> ids.add(p.id));
        return class_2172.method_9265(ids, b);
    };

    public static final SuggestionProvider<class_2168> TYPES = (ctx, b) -> {
        List<String> ids = new ArrayList<>();
        for (PokeType t : PokeType.values()) ids.add(t.id);
        return class_2172.method_9265(ids, b);
    };

    private Cmd() {}

    /** Resout un joueur (en ligne ou hors-ligne connu du serveur). */
    public static boolean profile(class_2168 src, String name, Consumer<GameProfile> then) {
        Optional<GameProfile> gp = PlayerDataManager.resolve(src.method_9211(), name);
        if (gp.isEmpty() || gp.get().getId() == null) {
            Msg.send(src, "general.player_not_found", "player", name);
            return false;
        }
        then.accept(gp.get());
        return true;
    }
}
