package fr.cobblepulse.core;

import fr.cobblepulse.config.Cfg;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.class_7923;

/** Effets visuels et sonores (titres, particules d'entree en arene). */
public final class Fx {
    private Fx() {}

    public static void title(class_3222 p, String title, String subtitle) {
        if (p == null || p.field_13987 == null) return;
        try {
            p.field_13987.method_14364(new class_5905(4, 22, 6));
            p.field_13987.method_14364(new class_5903(TextUtil.legacy(subtitle == null ? "" : subtitle)));
            p.field_13987.method_14364(new class_5904(TextUtil.legacy(title == null ? "" : title)));
        } catch (Throwable ignored) {
        }
    }

    public static void sound(class_3222 p, class_3414 sound, float pitch) {
        p.method_51469().method_43128(null, p.method_23317(), p.method_23318(), p.method_23321(), sound, class_3419.field_15248, 0.8f, pitch);
    }

    public static void click(class_3222 p) {
        sound(p, class_3417.field_15015.comp_349(), 1.2f);
    }

    /** Effet d'entree en arene reserve aux joueurs ayant cobblepulse.cosmetic.arena_effect. */
    public static void arenaEntrance(class_3222 p) {
        if (!Perms.vip(p, Perms.ARENA_EFFECT)) return;
        class_2394 particle = class_2398.field_11220;
        class_2960 id = class_2960.method_12829(Cfg.league.str("cosmetics.arena_particle", "minecraft:totem_of_undying"));
        if (id != null && class_7923.field_41180.method_10250(id)
                && class_7923.field_41180.method_10223(id) instanceof class_2400 simple) {
            particle = simple;
        }
        p.method_51469().method_14199(particle, p.method_23317(), p.method_23318() + 1.0, p.method_23321(),
                Math.max(1, Cfg.league.i("cosmetics.arena_particle_count", 60)), 0.6, 1.0, 0.6, 0.25);
        class_2960 sid = class_2960.method_12829(Cfg.league.str("cosmetics.arena_sound", "minecraft:entity.player.levelup"));
        class_3414 sound = sid != null && class_7923.field_41172.method_10250(sid) ? class_7923.field_41172.method_10223(sid) : class_3417.field_14709;
        sound(p, sound, 1.0f);
    }
}
