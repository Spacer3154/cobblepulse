package fr.cobblepulse.core;

import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.Locale;

/** Position serialisable (dimension + coordonnees + orientation). */
public final class Loc {
    public String world;
    public double x;
    public double y;
    public double z;
    public float yaw;
    public float pitch;

    public Loc() {}

    public Loc(String world, double x, double y, double z, float yaw, float pitch) {
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public static Loc of(class_3222 p) {
        return new Loc(p.method_51469().method_27983().method_29177().toString(), p.method_23317(), p.method_23318(), p.method_23321(), p.method_36454(), p.method_36455());
    }

    public class_3218 level(MinecraftServer server) {
        class_2960 id = class_2960.method_12829(world == null ? "minecraft:overworld" : world);
        if (id == null) return null;
        class_5321<class_1937> key = class_5321.method_29179(class_7924.field_41223, id);
        return server.method_3847(key);
    }

    public boolean teleport(class_3222 p) {
        class_3218 level = level(p.field_13995);
        if (level == null) return false;
        p.method_5848();
        p.method_14251(level, x, y, z, yaw, pitch);
        return true;
    }

    public String pretty() {
        return String.format(Locale.ROOT, "%s %.1f %.1f %.1f", world, x, y, z);
    }

    public Loc copy() {
        return new Loc(world, x, y, z, yaw, pitch);
    }
}
