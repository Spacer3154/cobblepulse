package fr.cobblepulse.core;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9296;
import net.minecraft.class_9334;

/** Construction d'items d'interface (nom, lore, brillance, tete de joueur). */
public final class ItemBuilder {
    private final class_1799 stack;
    private final List<class_2561> lore = new ArrayList<>();

    private ItemBuilder(class_1799 stack) {
        this.stack = stack;
    }

    public static ItemBuilder of(class_1792 item) {
        return new ItemBuilder(new class_1799(item));
    }

    public static ItemBuilder of(class_1799 stack) {
        return new ItemBuilder(stack.method_7972());
    }

    /** Item depuis un identifiant "modid:item" ; barriere si introuvable. */
    public static ItemBuilder of(String id) {
        return new ItemBuilder(new class_1799(item(id, class_1802.field_8077)));
    }

    public static class_1792 item(String id, class_1792 fallback) {
        class_2960 rl = id == null ? null : class_2960.method_12829(id.trim());
        if (rl == null || !class_7923.field_41178.method_10250(rl)) return fallback;
        return class_7923.field_41178.method_10223(rl);
    }

    public static boolean exists(String id) {
        class_2960 rl = id == null ? null : class_2960.method_12829(id.trim());
        return rl != null && class_7923.field_41178.method_10250(rl);
    }

    public ItemBuilder name(String legacy) {
        stack.method_57379(class_9334.field_49631, TextUtil.item(legacy));
        return this;
    }

    public ItemBuilder name(class_2561 c) {
        stack.method_57379(class_9334.field_49631, class_2561.method_43473().method_27694(s -> s.method_10978(false)).method_10852(c));
        return this;
    }

    public ItemBuilder lore(String... legacyLines) {
        for (String l : legacyLines) {
            if (l == null) continue;
            for (String part : l.split("\n")) lore.add(TextUtil.item(part));
        }
        return this;
    }

    public ItemBuilder lore(List<String> legacyLines) {
        return lore(legacyLines.toArray(new String[0]));
    }

    public ItemBuilder loreComponent(class_2561 c) {
        lore.add(class_2561.method_43473().method_27694(s -> s.method_10978(false)).method_10852(c));
        return this;
    }

    public ItemBuilder glow(boolean glow) {
        if (glow) stack.method_57379(class_9334.field_49641, true);
        return this;
    }

    public ItemBuilder count(int count) {
        stack.method_7939(Math.max(1, Math.min(stack.method_7914(), count)));
        return this;
    }

    public ItemBuilder head(GameProfile profile) {
        if (profile != null) stack.method_57379(class_9334.field_49617, new class_9296(profile));
        return this;
    }

    public ItemBuilder hideExtra() {
        stack.method_57379(class_9334.field_49638, net.minecraft.class_3902.field_17274);
        return this;
    }

    public class_1799 build() {
        if (!lore.isEmpty()) stack.method_57379(class_9334.field_49632, new class_9290(new ArrayList<>(lore)));
        return stack;
    }
}
