package fr.cobblepulse.core;

import fr.cobblepulse.CobblePulse;
import fr.cobblepulse.config.Cfg;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/** Messages configurables (messages.toml) avec placeholders %cle%. */
public final class Msg {
    private Msg() {}

    public static String raw(String key) {
        if (Cfg.messages == null) return key;
        String v = Cfg.messages.str(key, null);
        if (v == null) {
            CobblePulse.LOG.warn("[CobblePulse] Message manquant dans messages.toml : {}", key);
            return key;
        }
        return v;
    }

    public static String format(String key, Object... kv) {
        String s = raw(key);
        if (s.contains("%prefix%")) s = s.replace("%prefix%", raw("general.prefix"));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("%" + kv[i] + "%", String.valueOf(kv[i + 1]));
        }
        return s;
    }

    public static class_5250 get(String key, Object... kv) {
        return TextUtil.legacy(format(key, kv));
    }

    public static void send(class_3222 p, String key, Object... kv) {
        if (p != null) p.method_43496(get(key, kv));
    }

    public static void send(UUID uuid, String key, Object... kv) {
        MinecraftServer s = CobblePulse.server();
        if (s == null || uuid == null) return;
        class_3222 p = s.method_3760().method_14602(uuid);
        if (p != null) p.method_43496(get(key, kv));
    }

    public static void send(class_2168 src, String key, Object... kv) {
        src.method_45068(get(key, kv));
    }

    public static void broadcast(String key, Object... kv) {
        broadcast(get(key, kv));
    }

    public static void broadcast(class_2561 c) {
        MinecraftServer s = CobblePulse.server();
        if (s != null) s.method_3760().method_43514(c, false);
    }

    public static void actionBar(class_3222 p, String key, Object... kv) {
        if (p != null) p.method_7353(get(key, kv), true);
    }
}
