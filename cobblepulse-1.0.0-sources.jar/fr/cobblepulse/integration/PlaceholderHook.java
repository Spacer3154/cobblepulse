package fr.cobblepulse.integration;

import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import fr.cobblepulse.clan.ClanManager;
import fr.cobblepulse.core.TextUtil;
import fr.cobblepulse.config.Cfg;
import fr.cobblepulse.data.ClanData;
import fr.cobblepulse.data.LeagueData;
import fr.cobblepulse.league.LeagueManager;
import fr.cobblepulse.storage.PlayerDataManager;
import fr.cobblepulse.storage.StateManager;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/** Placeholders %cobblepulse:...% (Text Placeholder API). Ne jamais referencer si le mod est absent. */
final class PlaceholderHook {
    private PlaceholderHook() {}

    private static void reg(String id, Function<class_3222, class_2561> fn) {
        Placeholders.register(class_2960.method_60655("cobblepulse", id), (ctx, arg) -> {
            class_3222 p = ctx.player();
            if (p == null) return PlaceholderResult.invalid("No player!");
            return PlaceholderResult.value(fn.apply(p));
        });
    }

    /** Texte LuckPerms colore (&, &#RRGGBB, <#RRGGBB>) suivi d'un espace s'il n'est pas vide. */
    private static class_2561 metaComponent(String s) {
        if (s == null || s.isBlank()) return class_2561.method_43473();
        String v = s.endsWith(" ") ? s : s + " ";
        return TextUtil.legacy(v);
    }

    static void register() {
        reg("clan_tag", ClanManager::formattedTag);
        reg("clan_name", p -> {
            ClanData c = ClanManager.clanOf(p.method_5667());
            return class_2561.method_43470(c == null ? "" : c.name);
        });
        reg("clan_role", p -> {
            ClanData c = ClanManager.clanOf(p.method_5667());
            ClanManager.Role r = c == null ? null : ClanManager.role(c, p.method_5667());
            return class_2561.method_43470(r == null ? "" : r.name());
        });
        reg("clan_influence", p -> {
            ClanData c = ClanManager.clanOf(p.method_5667());
            return class_2561.method_43470(c == null ? "0" : String.valueOf(c.influence));
        });
        reg("league_grade", p -> {
            LeagueData.PostData post = LeagueManager.postOf(p.method_5667());
            return post == null ? class_2561.method_43473() : TextUtil.legacy(LeagueManager.prefix(post));
        });
        reg("chat_prefix", p -> {
            net.minecraft.class_5250 out = class_2561.method_43473();
            LeagueData.PostData post = LeagueManager.postOf(p.method_5667());
            if (post != null && LeagueManager.rankMode().equals("none")) out.method_10852(TextUtil.legacy(LeagueManager.prefix(post)));
            if (Cfg.tournament.str("winner_luckperms_mode", "group").equalsIgnoreCase("none")
                    && p.method_5667().toString().equals(StateManager.get().tournamentWinnerUuid)) {
                out.method_10852(TextUtil.legacy(Cfg.tournament.str("winner_prefix", "&e[Vainqueur Tournoi] ")));
            }
            out.method_10852(ClanManager.formattedTag(p));
            return out;
        });
        reg("lp_prefix", p -> metaComponent(LuckPermsBridge.meta(p, true)));
        reg("lp_suffix", p -> metaComponent(LuckPermsBridge.meta(p, false)));
        reg("badges", p -> class_2561.method_43470(String.valueOf(PlayerDataManager.online(p).badges.size())));
        reg("tournament_winner", p -> p.method_5667().toString().equals(StateManager.get().tournamentWinnerUuid)
                ? TextUtil.legacy(Cfg.tournament.str("winner_prefix", "&e[Vainqueur Tournoi] ")) : class_2561.method_43473());
    }
}
