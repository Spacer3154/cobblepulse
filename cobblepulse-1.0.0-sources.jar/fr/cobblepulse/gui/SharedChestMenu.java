package fr.cobblepulse.gui;

import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;

/** Coffre modifiable (inventaire de clan, editeur de recompenses) avec controle d'acces continu. */
public final class SharedChestMenu extends class_1707 {
    private final Predicate<class_1657> access;
    private final Consumer<class_1657> onClose;

    public SharedChestMenu(int id, class_1661 inv, class_1263 container, int rows, Predicate<class_1657> access, Consumer<class_1657> onClose) {
        super(LockedMenu.type(rows), id, inv, container, rows);
        this.access = access;
        this.onClose = onClose;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return access.test(player);
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        if (onClose != null) onClose.accept(player);
    }
}
