package fr.cobblepulse.gui;

import fr.cobblepulse.core.ItemBuilder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

/** Menus utilitaires : confirmation, choix d'un joueur en ligne. */
public final class Guis {
    private Guis() {}

    public static void confirm(class_3222 player, String title, String question, Runnable yes, Runnable no) {
        Gui gui = new Gui(3, title);
        gui.fill(Gui.pane());
        gui.button(11, ItemBuilder.of(class_1802.field_8839).name("&a&lConfirmer").lore("&7" + question).build(), p -> {
            p.method_7346();
            yes.run();
        });
        gui.button(15, ItemBuilder.of(class_1802.field_8197).name("&c&lAnnuler").build(), p -> {
            p.method_7346();
            if (no != null) no.run();
        });
        gui.open(player);
    }

    public static void pickOnlinePlayer(class_3222 viewer, String title, Consumer<class_3222> onPick, Consumer<class_3222> back) {
        List<class_3222> players = new ArrayList<>(viewer.field_13995.method_3760().method_14571());
        players.sort(Comparator.comparing(p -> p.method_7334().getName().toLowerCase()));
        List<Paged.Entry> entries = new ArrayList<>();
        for (class_3222 target : players) {
            entries.add(new Paged.Entry(ItemBuilder.of(class_1802.field_8575).head(target.method_7334())
                    .name("&e" + target.method_7334().getName()).lore("&7Cliquez pour selectionner").build(),
                    (p, c) -> {
                        class_3222 fresh = p.field_13995.method_3760().method_14602(target.method_5667());
                        if (fresh != null) onPick.accept(fresh);
                        else p.method_7346();
                    }));
        }
        Paged.open(viewer, title, entries, 0, back);
    }
}
