package fr.cobblepulse.gui;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

/** Vue sur les N premiers emplacements d'un conteneur (inventaire de clan 27 emplacements pour les non-VIP). */
public final class SubContainer implements class_1263 {
    private final class_1263 parent;
    private final int size;

    public SubContainer(class_1263 parent, int size) {
        this.parent = parent;
        this.size = Math.min(size, parent.method_5439());
    }

    @Override
    public int method_5439() {
        return size;
    }

    @Override
    public boolean method_5442() {
        for (int i = 0; i < size; i++) if (!parent.method_5438(i).method_7960()) return false;
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return slot < size ? parent.method_5438(slot) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        return slot < size ? parent.method_5434(slot, amount) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5441(int slot) {
        return slot < size ? parent.method_5441(slot) : class_1799.field_8037;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if (slot < size) parent.method_5447(slot, stack);
    }

    @Override
    public void method_5431() {
        parent.method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        for (int i = 0; i < size; i++) parent.method_5447(i, class_1799.field_8037);
    }
}
