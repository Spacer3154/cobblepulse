package fr.cobblepulse.clan;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import fr.cobblepulse.command.Cmd;
import fr.cobblepulse.core.Msg;
import fr.cobblepulse.core.Perms;
import fr.cobblepulse.core.TextUtil;
import fr.cobblepulse.data.ClanData;
import fr.cobblepulse.data.WarData;
import fr.cobblepulse.core.TimeFmt;
import fr.cobblepulse.gui.Guis;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** Commandes /clan. */
public final class ClanCommands {
    private static final SuggestionProvider<class_2168> CLANS = (ctx, b) -> {
        List<String> names = new ArrayList<>();
        for (ClanData c : ClanManager.all()) names.add(c.name);
        return class_2172.method_9265(names, b);
    };

    private static final SuggestionProvider<class_2168> MEMBERS = (ctx, b) -> {
        List<String> names = new ArrayList<>();
        if (ctx.getSource().method_44023() != null) {
            ClanData c = ClanManager.clanOf(ctx.getSource().method_44023().method_5667());
            if (c != null) c.members.values().forEach(m -> names.add(m.name));
        }
        return class_2172.method_9265(names, b);
    };

    private ClanCommands() {}

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(method_9247("clan").requires(Perms.playerReq(Perms.CLAN_USE))
                .executes(ctx -> {
                    ClanGuis.open(ctx.getSource().method_9207());
                    return 1;
                })
                .then(method_9247("create").requires(Perms.playerReq(Perms.CLAN_CREATE))
                        .then(method_9244("nom", StringArgumentType.word()).then(method_9244("tag", StringArgumentType.word()).executes(ctx -> {
                            ClanManager.create(ctx.getSource().method_9207(), StringArgumentType.getString(ctx, "nom"),
                                    StringArgumentType.getString(ctx, "tag"));
                            return 1;
                        }))))
                .then(method_9247("join").then(method_9244("nom", StringArgumentType.word()).suggests(CLANS).executes(ctx -> {
                    ClanData c = clan(ctx);
                    if (c != null) ClanManager.join(ctx.getSource().method_9207(), c);
                    return 1;
                })))
                .then(method_9247("request").then(method_9244("nom", StringArgumentType.word()).suggests(CLANS).executes(ctx -> {
                    ClanData c = clan(ctx);
                    if (c != null) ClanManager.request(ctx.getSource().method_9207(), c);
                    return 1;
                })))
                .then(method_9247("accept").then(method_9244("nom", StringArgumentType.word()).suggests(CLANS).executes(ctx -> {
                    ClanData c = clan(ctx);
                    if (c != null) ClanManager.acceptInvite(ctx.getSource().method_9207(), c);
                    return 1;
                })))
                .then(method_9247("deny").then(method_9244("nom", StringArgumentType.word()).suggests(CLANS).executes(ctx -> {
                    ClanData c = clan(ctx);
                    if (c != null) ClanManager.denyInvite(ctx.getSource().method_9207(), c);
                    return 1;
                })))
                .then(method_9247("invite").then(method_9244("joueur", StringArgumentType.word()).suggests(Cmd.ONLINE).executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    class_3222 t = p.field_13995.method_3760().method_14566(StringArgumentType.getString(ctx, "joueur"));
                    if (t == null) {
                        Msg.send(p, "general.player_not_found", "player", StringArgumentType.getString(ctx, "joueur"));
                        return 0;
                    }
                    ClanManager.invite(p, t);
                    return 1;
                })))
                .then(method_9247("requests").executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    ClanData c = ClanManager.clanOf(p.method_5667());
                    if (c == null) {
                        Msg.send(p, "clan.err_no_clan");
                        return 0;
                    }
                    if (c.requests.isEmpty()) Msg.send(p, "clan.no_requests");
                    for (Map.Entry<String, ClanData.JoinRequest> e : c.requests.entrySet()) {
                        p.method_43496(TextUtil.legacy("&7- &f" + e.getValue().name + " ")
                                .method_10852(TextUtil.button("&a[✔]", "/clan requests accept " + e.getValue().name, null))
                                .method_10852(TextUtil.legacy(" "))
                                .method_10852(TextUtil.button("&c[✘]", "/clan requests deny " + e.getValue().name, null)));
                    }
                    return 1;
                }).then(method_9247("accept").then(method_9244("joueur", StringArgumentType.word()).executes(ctx -> handleRequest(ctx, true))))
                        .then(method_9247("deny").then(method_9244("joueur", StringArgumentType.word()).executes(ctx -> handleRequest(ctx, false)))))
                .then(method_9247("leave").executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    Guis.confirm(p, "&cQuitter le clan ?", "Quitter votre clan", () -> ClanManager.leave(p), null);
                    return 1;
                }))
                .then(method_9247("kick").then(method_9244("joueur", StringArgumentType.word()).suggests(MEMBERS).executes(ctx -> member(ctx, "kick"))))
                .then(method_9247("promote").then(method_9244("joueur", StringArgumentType.word()).suggests(MEMBERS).executes(ctx -> member(ctx, "promote"))))
                .then(method_9247("demote").then(method_9244("joueur", StringArgumentType.word()).suggests(MEMBERS).executes(ctx -> member(ctx, "demote"))))
                .then(method_9247("transfer").then(method_9244("joueur", StringArgumentType.word()).suggests(MEMBERS).executes(ctx -> member(ctx, "transfer"))))
                .then(method_9247("disband").executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    Guis.confirm(p, "&4Dissoudre le clan ?", "Action définitive", () -> ClanManager.disband(p), null);
                    return 1;
                }))
                .then(method_9247("mode").then(method_9244("mode", StringArgumentType.word())
                        .suggests((c, b) -> class_2172.method_9265(List.of("open", "invite", "closed"), b)).executes(ctx -> {
                            class_3222 p = ctx.getSource().method_9207();
                            String m = StringArgumentType.getString(ctx, "mode").toLowerCase(Locale.ROOT);
                            ClanManager.Mode mode = switch (m) {
                                case "open", "ouvert" -> ClanManager.Mode.OPEN;
                                case "closed", "ferme", "fermé" -> ClanManager.Mode.CLOSED;
                                default -> ClanManager.Mode.INVITE_ONLY;
                            };
                            ClanManager.setMode(p, mode);
                            return 1;
                        })))
                .then(method_9247("inventory").requires(Perms.playerReq(Perms.CLAN_INVENTORY)).executes(ctx -> {
                    ClanGuis.openInventory(ctx.getSource().method_9207());
                    return 1;
                }))
                .then(method_9247("tagcolor").then(method_9244("couleur", StringArgumentType.greedyString()).executes(ctx -> {
                    ClanManager.setTagColor(ctx.getSource().method_9207(), StringArgumentType.getString(ctx, "couleur").trim());
                    return 1;
                })))
                .then(method_9247("list").executes(ctx -> {
                    ClanGuis.openList(ctx.getSource().method_9207(), 0);
                    return 1;
                }))
                .then(method_9247("top").executes(ctx -> {
                    if (ctx.getSource().method_43737()) {
                        ClanGuis.openLeaderboard(ctx.getSource().method_9207());
                    } else {
                        int i = 1;
                        for (ClanData c : ClanManager.leaderboard()) {
                            if (i > 10) break;
                            ctx.getSource().method_45068(TextUtil.legacy("&e#" + i++ + " &f" + c.name + " &7- influence &d" + c.influence
                                    + " &7- guerres " + c.warWins + "V/" + c.warLosses + "D"));
                        }
                    }
                    return 1;
                }))
                .then(method_9247("info").executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    ClanData c = ClanManager.clanOf(p.method_5667());
                    if (c == null) {
                        Msg.send(p, "clan.err_no_clan");
                        return 0;
                    }
                    info(ctx.getSource(), c);
                    return 1;
                }).then(method_9244("nom", StringArgumentType.word()).suggests(CLANS).executes(ctx -> {
                    ClanData c = clan(ctx);
                    if (c != null) info(ctx.getSource(), c);
                    return 1;
                })))
                .then(method_9247("war")
                        .then(method_9247("declare").then(method_9244("nom", StringArgumentType.word()).suggests(CLANS).executes(ctx -> {
                            ClanData c = clan(ctx);
                            if (c != null) WarManager.declare(ctx.getSource().method_9207(), c);
                            return 1;
                        })))
                        .then(method_9247("status").executes(ctx -> {
                            class_3222 p = ctx.getSource().method_9207();
                            ClanData c = ClanManager.clanOf(p.method_5667());
                            WarData w = c == null ? null : WarManager.activeWar(c);
                            if (w == null) {
                                Msg.send(p, "war.none");
                                return 0;
                            }
                            String enemy = w.attackerId.equals(c.id) ? w.defenderName : w.attackerName;
                            Msg.send(p, "war.status", "clan", enemy, "score", WarManager.score(w, c), "time", TimeFmt.duration(w.endsAt - TimeFmt.now()));
                            return 1;
                        }))));
    }

    private static ClanData clan(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "nom");
        ClanData c = ClanManager.byName(name);
        if (c == null) Msg.send(ctx.getSource(), "clan.err_unknown", "clan", name);
        return c;
    }

    private static int handleRequest(CommandContext<class_2168> ctx, boolean accept) throws CommandSyntaxException {
        class_3222 p = ctx.getSource().method_9207();
        ClanData c = ClanManager.clanOf(p.method_5667());
        if (c == null) {
            Msg.send(p, "clan.err_no_clan");
            return 0;
        }
        String name = StringArgumentType.getString(ctx, "joueur");
        for (Map.Entry<String, ClanData.JoinRequest> e : c.requests.entrySet()) {
            if (e.getValue().name.equalsIgnoreCase(name)) {
                UUID u = UUID.fromString(e.getKey());
                if (accept) ClanManager.acceptRequest(p, u);
                else ClanManager.denyRequest(p, u);
                return 1;
            }
        }
        Msg.send(p, "clan.err_no_request");
        return 0;
    }

    private static int member(CommandContext<class_2168> ctx, String action) throws CommandSyntaxException {
        class_3222 p = ctx.getSource().method_9207();
        ClanData c = ClanManager.clanOf(p.method_5667());
        if (c == null) {
            Msg.send(p, "clan.err_no_clan");
            return 0;
        }
        String name = StringArgumentType.getString(ctx, "joueur");
        UUID target = null;
        for (Map.Entry<String, ClanData.ClanMember> e : c.members.entrySet()) {
            if (e.getValue().name.equalsIgnoreCase(name)) target = UUID.fromString(e.getKey());
        }
        if (target == null) {
            Msg.send(p, "clan.err_not_member");
            return 0;
        }
        UUID t = target;
        switch (action) {
            case "kick" -> ClanManager.kick(p, t);
            case "promote" -> ClanManager.setRole(p, t, ClanManager.Role.OFFICER);
            case "demote" -> ClanManager.setRole(p, t, ClanManager.Role.MEMBER);
            case "transfer" -> Guis.confirm(p, "&6Transférer la direction ?", "Nouveau chef : " + name, () -> ClanManager.transfer(p, t), null);
            default -> {
            }
        }
        return 1;
    }

    private static void info(class_2168 src, ClanData c) {
        ClanData.ClanMember leader = c.members.get(c.leader);
        src.method_45068(TextUtil.legacy("&8&m          &r &f&l" + c.name + " " + ClanManager.tagString(c, true) + "&8&m          "));
        src.method_45068(TextUtil.legacy("&7Chef : &f" + (leader == null ? "?" : leader.name) + " &7- Membres : &f" + c.members.size()
                + " &7- Recrutement : " + ClanManager.modeLabel(ClanManager.mode(c))));
        src.method_45068(TextUtil.legacy("&7Influence : &d" + c.influence + " &8(#" + ClanManager.rank(c) + ") &7- PvP : &a" + c.pvpWins
                + "&7/&c" + c.pvpLosses + " &7- Guerres : &a" + c.warWins + "&7/&c" + c.warLosses + "&7/&e" + c.warDraws));
    }
}
