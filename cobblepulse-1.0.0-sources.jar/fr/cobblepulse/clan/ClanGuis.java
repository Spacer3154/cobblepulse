package fr.cobblepulse.clan;

import com.mojang.authlib.GameProfile;
import fr.cobblepulse.core.ItemBuilder;
import fr.cobblepulse.core.Msg;
import fr.cobblepulse.core.Perms;
import fr.cobblepulse.core.Players;
import fr.cobblepulse.core.TextUtil;
import fr.cobblepulse.core.TimeFmt;
import fr.cobblepulse.data.ClanData;
import fr.cobblepulse.data.WarData;
import fr.cobblepulse.gui.Gui;
import fr.cobblepulse.gui.Guis;
import fr.cobblepulse.gui.Paged;
import fr.cobblepulse.gui.SharedChestMenu;
import fr.cobblepulse.gui.SubContainer;
import fr.cobblepulse.menu.MainMenu;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/** Interfaces du module Clan : gestion, membres, inventaire partage, recrutement, guerres, classement. */
public final class ClanGuis {
    private static final String[][] COLORS = {
            {"&0", "Noir"}, {"&1", "Bleu foncé"}, {"&2", "Vert foncé"}, {"&3", "Cyan"}, {"&4", "Rouge foncé"}, {"&5", "Violet"},
            {"&6", "Or"}, {"&7", "Gris"}, {"&8", "Gris foncé"}, {"&9", "Bleu"}, {"&a", "Vert"}, {"&b", "Aqua"}, {"&c", "Rouge"},
            {"&d", "Rose"}, {"&e", "Jaune"}, {"&f", "Blanc"}};
    private static final class_1792[] COLOR_ITEMS = {
            class_1802.field_19059, class_1802.field_19055, class_1802.field_19057, class_1802.field_19053, class_1802.field_19058, class_1802.field_19054, class_1802.field_19045,
            class_1802.field_19052, class_1802.field_19051, class_1802.field_19047, class_1802.field_19049, class_1802.field_19047, class_1802.field_19058,
            class_1802.field_19050, class_1802.field_19048, class_1802.field_19044};

    private ClanGuis() {}

    public static void open(class_3222 p) {
        ClanData c = ClanManager.clanOf(p.method_5667());
        if (c == null) openNoClan(p);
        else openClan(p, c);
    }

    private static List<String> clanInfo(ClanData c) {
        List<String> lore = new ArrayList<>();
        ClanData.ClanMember leader = c.members.get(c.leader);
        lore.add("&7Tag : " + ClanManager.tagString(c, true));
        lore.add("&7Chef : &f" + (leader == null ? "?" : leader.name));
        lore.add("&7Membres : &f" + c.members.size());
        lore.add("&7Recrutement : " + ClanManager.modeLabel(ClanManager.mode(c)));
        lore.add("&7Influence : &d" + c.influence + " &8(#" + ClanManager.rank(c) + ")");
        lore.add("&7PvP inter-clans : &a" + c.pvpWins + "V &7/ &c" + c.pvpLosses + "D");
        lore.add("&7Guerres : &a" + c.warWins + "V &7/ &c" + c.warLosses + "D &7/ &e" + c.warDraws + "N");
        WarData w = WarManager.activeWar(c);
        if (w != null) {
            String enemy = w.attackerId.equals(c.id) ? w.defenderName : w.attackerName;
            lore.add("&c⚔ En guerre contre " + enemy + " &7(" + WarManager.score(w, c) + ")");
        }
        return lore;
    }

    // ------------------------------------------------------------------ sans clan

    public static void openNoClan(class_3222 p) {
        Gui gui = new Gui(3, "&8Clans");
        gui.set(11, ItemBuilder.of(class_1802.field_8674).name("&a&lCréer un clan").lore("&7Commande :", "&f/clan create <nom> <tag>").build());
        gui.button(13, ItemBuilder.of(class_1802.field_8539).name("&e&lListe des clans").lore("&7Rejoindre ou postuler").build(), x -> openList(x, 0));
        gui.button(15, ItemBuilder.of(class_1802.field_8494).name("&6&lClassement").lore("&7Influence et guerres").build(), ClanGuis::openLeaderboard);
        List<String> invites = new ArrayList<>();
        for (ClanData c : ClanManager.all()) {
            Long exp = c.invites.get(p.method_5667().toString());
            if (exp != null && exp > TimeFmt.now()) invites.add("&f- " + c.name + " &8(/clan accept " + c.name + ")");
        }
        if (!invites.isEmpty()) {
            gui.set(4, ItemBuilder.of(class_1802.field_8407).name("&eInvitations en attente").lore(invites).glow(true).build());
        }
        gui.button(22, ItemBuilder.of(class_1802.field_8691).name("&cRetour").build(), MainMenu::open);
        gui.fill(Gui.pane());
        gui.open(p);
    }

    public static void openList(class_3222 p, int page) {
        List<Paged.Entry> entries = new ArrayList<>();
        for (ClanData c : ClanManager.leaderboard()) {
            ClanManager.Mode m = ClanManager.mode(c);
            List<String> lore = clanInfo(c);
            lore.add("");
            if (ClanManager.clanOf(p.method_5667()) == null) {
                lore.add(switch (m) {
                    case OPEN -> "&aCliquez pour rejoindre";
                    case INVITE_ONLY -> "&eCliquez pour envoyer une demande";
                    case CLOSED -> "&cRecrutement fermé";
                });
            }
            entries.add(new Paged.Entry(ItemBuilder.of(bannerFor(m)).name("&f&l" + c.name).lore(lore).hideExtra().build(), (pl, click) -> {
                if (ClanManager.clanOf(pl.method_5667()) != null) return;
                ClanManager.join(pl, c);
                pl.method_7346();
            }));
        }
        Paged.open(p, "&8Liste des clans", entries, page, ClanGuis::open);
    }

    private static class_1792 bannerFor(ClanManager.Mode m) {
        return switch (m) {
            case OPEN -> class_1802.field_8778;
            case INVITE_ONLY -> class_1802.field_8049;
            case CLOSED -> class_1802.field_8586;
        };
    }

    // ------------------------------------------------------------------ gestion du clan

    public static void openClan(class_3222 p, ClanData c) {
        ClanManager.Role role = ClanManager.role(c, p.method_5667());
        boolean leader = role == ClanManager.Role.LEADER;
        boolean officer = ClanManager.isOfficer(c, p.method_5667());
        Gui gui = new Gui(6, "&8Clan &f" + c.name + " " + ClanManager.tagString(c, true));
        gui.set(4, ItemBuilder.of(class_1802.field_8539).name("&f&l" + c.name).lore(clanInfo(c)).hideExtra().build());
        gui.button(19, ItemBuilder.of(class_1802.field_8575).name("&e&lMembres").lore("&7" + c.members.size() + " membres", "&7Gérer les rôles et exclusions").build(),
                x -> openMembers(x, c, 0));
        if (Perms.player(p, Perms.CLAN_INVENTORY)) {
            int slots = ClanManager.inventorySlots(p);
            gui.button(21, ItemBuilder.of(class_1802.field_8106).name("&6&lInventaire partagé").lore("&7Capacité : &f" + slots + " emplacements",
                    slots < ClanManager.INVENTORY_SIZE ? "&8VIP : 54 emplacements" : "&dAccès VIP étendu").build(), ClanGuis::openInventory);
        }
        ClanManager.Mode mode = ClanManager.mode(c);
        gui.button(23, ItemBuilder.of(bannerFor(mode)).name("&b&lRecrutement").lore("&7Mode : " + ClanManager.modeLabel(mode),
                leader ? "&eCliquez pour changer" : "&8Réservé au chef").hideExtra().build(), x -> {
            if (!leader) return;
            ClanManager.Mode next = ClanManager.Mode.values()[(mode.ordinal() + 1) % ClanManager.Mode.values().length];
            ClanManager.setMode(x, next);
            openClan(x, c);
        });
        if (officer) {
            gui.button(25, ItemBuilder.of(class_1802.field_8407).name("&e&lDemandes d'adhésion").lore("&7" + c.requests.size() + " en attente").glow(!c.requests.isEmpty()).build(),
                    x -> openRequests(x, c));
        }
        WarData w = WarManager.activeWar(c);
        List<String> warLore = new ArrayList<>();
        if (w != null) {
            String enemy = w.attackerId.equals(c.id) ? w.defenderName : w.attackerName;
            warLore.add("&cEn guerre contre &f" + enemy);
            warLore.add("&7Score : &f" + WarManager.score(w, c));
            warLore.add("&7Fin dans : &f" + TimeFmt.duration(w.endsAt - TimeFmt.now()));
        } else {
            warLore.add("&7Aucune guerre en cours");
            if (leader) warLore.add("&eCliquez pour déclarer la guerre");
        }
        for (WarData h : WarManager.history(c, 3)) {
            String enemy = h.attackerId.equals(c.id) ? h.defenderName : h.attackerName;
            String res = h.winnerId == null ? "&eNul" : h.winnerId.equals(c.id) ? "&aVictoire" : "&cDéfaite";
            warLore.add("&8- " + res + " &8vs " + enemy + " (" + WarManager.score(h, c) + ")");
        }
        gui.button(29, ItemBuilder.of(class_1802.field_8371).name("&c&lGuerres d'Influence").lore(warLore).hideExtra().build(), x -> {
            if (leader && WarManager.activeWar(c) == null) openDeclareWar(x, c, 0);
        });
        gui.button(31, ItemBuilder.of(class_1802.field_8494).name("&6&lClassement des clans").build(), ClanGuis::openLeaderboard);
        if (officer) {
            gui.button(33, ItemBuilder.of(class_1802.field_8632).name("&d&lCouleur du tag").lore("&7Actuel : " + ClanManager.tagString(c, true),
                    Perms.vip(p, Perms.CLAN_CHAT_COLOR) ? "&eCliquez pour choisir" : "&8Réservé aux VIP").build(), x -> {
                if (Perms.vip(x, Perms.CLAN_CHAT_COLOR)) openColors(x, c);
                else Msg.send(x, "clan.err_color_vip");
            });
        }
        if (leader) {
            gui.button(40, ItemBuilder.of(class_1802.field_8626).name("&4&lDissoudre le clan").build(), x -> Guis.confirm(x, "&4Dissoudre " + c.name + " ?",
                    "Cette action est définitive", () -> ClanManager.disband(x), () -> openClan(x, c)));
        } else {
            gui.button(40, ItemBuilder.of(class_1802.field_8077).name("&cQuitter le clan").build(), x -> Guis.confirm(x, "&cQuitter " + c.name + " ?",
                    "Quitter le clan", () -> ClanManager.leave(x), () -> openClan(x, c)));
        }
        gui.button(49, ItemBuilder.of(class_1802.field_8691).name("&cRetour").build(), MainMenu::open);
        gui.fill(Gui.pane());
        gui.open(p);
    }

    public static void openInventory(class_3222 p) {
        ClanData c = ClanManager.clanOf(p.method_5667());
        if (c == null) {
            Msg.send(p, "clan.err_no_clan");
            return;
        }
        if (!Perms.player(p, Perms.CLAN_INVENTORY)) {
            Msg.send(p, "general.no_permission");
            return;
        }
        class_1277 inv = ClanManager.inventory(c);
        int slots = Math.max(9, Math.min(54, (ClanManager.inventorySlots(p) / 9) * 9));
        int rows = slots / 9;
        class_1263 view = slots >= ClanManager.INVENTORY_SIZE ? inv : new SubContainer(inv, slots);
        String clanId = c.id;
        p.method_17355(new class_747((id, pinv, pl) -> new SharedChestMenu(id, pinv, view, rows,
                pl2 -> {
                    ClanData cur = ClanManager.clanOf(pl2.method_5667());
                    return cur != null && cur.id.equals(clanId);
                },
                pl2 -> ClanManager.save(c)), TextUtil.legacy("&6Inventaire de " + c.name)));
    }

    private static void openMembers(class_3222 p, ClanData c, int page) {
        boolean officer = ClanManager.isOfficer(c, p.method_5667());
        List<Paged.Entry> entries = new ArrayList<>();
        List<Map.Entry<String, ClanData.ClanMember>> members = new ArrayList<>(c.members.entrySet());
        members.sort((a, b) -> Integer.compare(roleOrder(a.getValue().role), roleOrder(b.getValue().role)));
        for (Map.Entry<String, ClanData.ClanMember> e : members) {
            UUID u = UUID.fromString(e.getKey());
            ClanData.ClanMember m = e.getValue();
            class_3222 online = Players.get(u);
            GameProfile gp = online != null ? online.method_7334() : new GameProfile(u, m.name);
            List<String> lore = new ArrayList<>();
            lore.add("&7Rôle : &f" + roleLabel(m.role));
            lore.add("&7Membre depuis : &f" + TimeFmt.date(m.joinedAt));
            lore.add(online != null ? "&aEn ligne" : "&8Hors-ligne");
            if (officer && !u.equals(p.method_5667())) lore.add("&eCliquez pour gérer");
            entries.add(new Paged.Entry(ItemBuilder.of(class_1802.field_8575).head(gp).name("&f" + m.name).lore(lore).build(), (pl, click) -> {
                if (ClanManager.isOfficer(c, pl.method_5667()) && !u.equals(pl.method_5667())) openMemberActions(pl, c, u);
            }));
        }
        Paged.open(p, "&8Membres de " + c.name, entries, page, x -> openClan(x, c));
    }

    private static int roleOrder(String role) {
        return switch (role) {
            case "LEADER" -> 0;
            case "OFFICER" -> 1;
            default -> 2;
        };
    }

    private static String roleLabel(String role) {
        return switch (role) {
            case "LEADER" -> "&6Chef";
            case "OFFICER" -> "&eOfficier";
            default -> "&7Membre";
        };
    }

    private static void openMemberActions(class_3222 p, ClanData c, UUID target) {
        ClanData.ClanMember m = c.members.get(target.toString());
        if (m == null) {
            openMembers(p, c, 0);
            return;
        }
        boolean leader = ClanManager.role(c, p.method_5667()) == ClanManager.Role.LEADER;
        Gui gui = new Gui(3, "&8Gérer " + m.name);
        if (leader) {
            if (!"OFFICER".equals(m.role)) {
                gui.button(10, ItemBuilder.of(class_1802.field_8695).name("&ePromouvoir officier").build(), x -> {
                    ClanManager.setRole(x, target, ClanManager.Role.OFFICER);
                    openMembers(x, c, 0);
                });
            } else {
                gui.button(10, ItemBuilder.of(class_1802.field_8620).name("&7Rétrograder membre").build(), x -> {
                    ClanManager.setRole(x, target, ClanManager.Role.MEMBER);
                    openMembers(x, c, 0);
                });
            }
            gui.button(12, ItemBuilder.of(class_1802.field_8862).name("&6Transférer la direction").hideExtra().build(),
                    x -> Guis.confirm(x, "&6Transférer ?", "Faire de " + m.name + " le chef du clan", () -> ClanManager.transfer(x, target), () -> openMembers(x, c, 0)));
        }
        gui.button(14, ItemBuilder.of(class_1802.field_8077).name("&cExclure").build(),
                x -> Guis.confirm(x, "&cExclure " + m.name + " ?", "Exclure du clan", () -> ClanManager.kick(x, target), () -> openMembers(x, c, 0)));
        gui.button(22, ItemBuilder.of(class_1802.field_8691).name("&cRetour").build(), x -> openMembers(x, c, 0));
        gui.fill(Gui.pane());
        gui.open(p);
    }

    private static void openRequests(class_3222 p, ClanData c) {
        List<Paged.Entry> entries = new ArrayList<>();
        for (Map.Entry<String, ClanData.JoinRequest> e : new ArrayList<>(c.requests.entrySet())) {
            UUID u = UUID.fromString(e.getKey());
            entries.add(new Paged.Entry(ItemBuilder.of(class_1802.field_8575).head(new GameProfile(u, e.getValue().name)).name("&f" + e.getValue().name)
                    .lore("&7Demande du " + TimeFmt.date(e.getValue().time), "&aClic gauche : accepter", "&cClic droit : refuser").build(), (pl, click) -> {
                if (click.right()) ClanManager.denyRequest(pl, u);
                else ClanManager.acceptRequest(pl, u);
                openRequests(pl, c);
            }));
        }
        Paged.open(p, "&8Demandes d'adhésion", entries, 0, x -> openClan(x, c));
    }

    private static void openDeclareWar(class_3222 p, ClanData c, int page) {
        List<Paged.Entry> entries = new ArrayList<>();
        for (ClanData other : ClanManager.leaderboard()) {
            if (other == c) continue;
            boolean busy = WarManager.activeWar(other) != null;
            List<String> lore = clanInfo(other);
            lore.add("");
            lore.add(busy ? "&cDéjà en guerre" : "&eCliquez pour déclarer la guerre");
            entries.add(new Paged.Entry(ItemBuilder.of(busy ? class_1802.field_8617 : class_1802.field_8586).name("&f" + other.name).lore(lore).hideExtra().build(),
                    (pl, click) -> {
                        if (busy) return;
                        Guis.confirm(pl, "&cGuerre contre " + other.name + " ?", "Déclarer une Guerre d'Influence",
                                () -> WarManager.declare(pl, other), () -> openClan(pl, c));
                    }));
        }
        Paged.open(p, "&cDéclarer la guerre", entries, page, x -> openClan(x, c));
    }

    private static void openColors(class_3222 p, ClanData c) {
        Gui gui = new Gui(3, "&dCouleur du tag");
        for (int i = 0; i < COLORS.length; i++) {
            String code = COLORS[i][0];
            gui.button(i, ItemBuilder.of(COLOR_ITEMS[i]).name(code + COLORS[i][1] + " &8(" + code + "[" + c.tag + "]&8)").build(), x -> {
                ClanManager.setTagColor(x, code);
                openClan(x, c);
            });
        }
        gui.set(22, ItemBuilder.of(class_1802.field_8448).name("&7Couleur hexadécimale").lore("&f/clan tagcolor &#RRGGBB").build());
        gui.button(26, ItemBuilder.of(class_1802.field_8691).name("&cRetour").build(), x -> openClan(x, c));
        gui.fill(Gui.pane());
        gui.open(p);
    }

    /** Podium visuel : influence totale puis victoires en guerre. */
    public static void openLeaderboard(class_3222 p) {
        List<ClanData> top = ClanManager.leaderboard();
        Gui gui = new Gui(6, "&6Classement des clans");
        int[] podiumSlots = {13, 21, 23};
        class_1792[] podiumBlocks = {class_1802.field_8494, class_1802.field_8773, class_1802.field_27071};
        class_1792[] banners = {class_1802.field_8049, class_1802.field_8855, class_1802.field_8824};
        String[] medals = {"&6&l1er", "&7&l2e", "&c&l3e"};
        for (int i = 0; i < 3; i++) {
            int slot = podiumSlots[i];
            gui.set(slot + 9, ItemBuilder.of(podiumBlocks[i]).name(medals[i]).build());
            if (i == 0) gui.set(slot + 18, ItemBuilder.of(podiumBlocks[i]).name(medals[i]).build());
            if (i < top.size()) {
                ClanData c = top.get(i);
                gui.set(slot, ItemBuilder.of(banners[i]).name(medals[i] + " &f" + c.name).lore(clanInfo(c)).glow(i == 0).hideExtra().build());
            } else {
                gui.set(slot, ItemBuilder.of(class_1802.field_8141).name(medals[i] + " &8- libre").build());
            }
        }
        int slot = 37;
        for (int i = 3; i < Math.min(top.size(), 10); i++) {
            ClanData c = top.get(i);
            gui.set(slot++, ItemBuilder.of(class_1802.field_8539).count(i + 1).name("&e#" + (i + 1) + " &f" + c.name).lore(clanInfo(c)).hideExtra().build());
        }
        ClanData mine = ClanManager.clanOf(p.method_5667());
        if (mine != null) {
            gui.set(4, ItemBuilder.of(class_1802.field_8448).name("&eVotre clan : &f" + mine.name).lore("&7Rang : &f#" + ClanManager.rank(mine),
                    "&7Influence : &d" + mine.influence).build());
        }
        gui.button(49, ItemBuilder.of(class_1802.field_8691).name("&cRetour").build(), ClanGuis::open);
        gui.fill(Gui.pane());
        gui.open(p);
    }
}
