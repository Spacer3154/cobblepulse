package fr.cobblepulse.menu;

import fr.cobblepulse.clan.ClanGuis;
import fr.cobblepulse.clan.ClanManager;
import fr.cobblepulse.core.ItemBuilder;
import fr.cobblepulse.core.Msg;
import fr.cobblepulse.core.Perms;
import fr.cobblepulse.data.ClanData;
import fr.cobblepulse.data.PlayerData;
import fr.cobblepulse.gui.Gui;
import fr.cobblepulse.league.LeagueGuis;
import fr.cobblepulse.profile.ProfileGui;
import fr.cobblepulse.storage.PlayerDataManager;
import fr.cobblepulse.tournament.TournamentGuis;
import fr.cobblepulse.tournament.TournamentManager;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

/** Hub central /cobblepulse (/cp). */
public final class MainMenu {
    private MainMenu() {}

    public static void open(class_3222 p) {
        if (!Perms.player(p, Perms.MENU)) {
            Msg.send(p, "general.no_permission");
            return;
        }
        PlayerData d = PlayerDataManager.online(p);
        ClanData clan = ClanManager.clanOf(p.method_5667());
        Gui gui = new Gui(3, Msg.raw("gui.main_title"));
        gui.button(10, ItemBuilder.of(class_1802.field_8529).name("&e&lÉtui à badges").lore("&7" + d.badges.size() + "/13 badges", "&8/league badges").glow(true).build(),
                x -> LeagueGuis.openBadgeCase(x, x.method_5667(), x.method_7334().getName(), PlayerDataManager.online(x), false));
        gui.button(12, ItemBuilder.of(class_1802.field_8539).name("&b&lClan").lore(clan == null ? "&7Aucun clan" : "&7" + clan.name + " " + ClanManager.tagString(clan, true),
                "&8/clan").hideExtra().build(), ClanGuis::open);
        gui.button(14, ItemBuilder.of(class_1802.field_8137).name("&6&lLa Ligue").lore("&78 Champions, Conseil 4 et Maître", "&8/league").build(), LeagueGuis::openLeague);
        String t = TournamentManager.current() == null ? "&7Aucun tournoi" : "&7" + TournamentManager.current().name;
        gui.button(16, ItemBuilder.of(class_1802.field_8845).name("&c&lTournois").lore(t, "&8/tournoi").hideExtra().build(), TournamentGuis::open);
        gui.button(22, ItemBuilder.of(class_1802.field_8575).head(p.method_7334()).name("&a&lMa carte de dresseur").lore("&8/profile").build(),
                x -> ProfileGui.open(x, x.method_5667(), x.method_7334().getName()));
        if (Perms.admin(p, Perms.ADMIN_LEAGUE)) {
            gui.button(26, ItemBuilder.of(class_1802.field_8866).name("&4Éditeur de Ligue").build(), LeagueGuis::openAdmin);
        }
        gui.fill(Gui.pane());
        gui.open(p);
    }
}
