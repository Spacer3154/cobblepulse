package fr.cobblepulse.league;

import java.util.Locale;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

/** Les 18 types Pokemon (identifiant Cobblemon, nom francais, couleur, icone). */
public enum PokeType {
    NORMAL("normal", "Normal", "&f", class_1802.field_19044),
    FIRE("fire", "Feu", "&c", class_1802.field_8183),
    WATER("water", "Eau", "&9", class_1802.field_8207),
    GRASS("grass", "Plante", "&a", class_1802.field_17535),
    ELECTRIC("electric", "Électrik", "&e", class_1802.field_8601),
    ICE("ice", "Glace", "&b", class_1802.field_8081),
    FIGHTING("fighting", "Combat", "&6", class_1802.field_8371),
    POISON("poison", "Poison", "&5", class_1802.field_8680),
    GROUND("ground", "Sol", "&6", class_1802.field_8460),
    FLYING("flying", "Vol", "&7", class_1802.field_8153),
    PSYCHIC("psychic", "Psy", "&d", class_1802.field_8634),
    BUG("bug", "Insecte", "&2", class_1802.field_8786),
    ROCK("rock", "Roche", "&6", class_1802.field_20412),
    GHOST("ghost", "Spectre", "&5", class_1802.field_8614),
    DRAGON("dragon", "Dragon", "&1", class_1802.field_8613),
    DARK("dark", "Ténèbres", "&8", class_1802.field_8794),
    STEEL("steel", "Acier", "&7", class_1802.field_8620),
    FAIRY("fairy", "Fée", "&d", class_1802.field_8330);

    public final String id;
    public final String fr;
    public final String color;
    public final class_1792 icon;

    PokeType(String id, String fr, String color, class_1792 icon) {
        this.id = id;
        this.fr = fr;
        this.color = color;
        this.icon = icon;
    }

    public String colored() {
        return color + fr;
    }

    public static PokeType of(String s) {
        if (s == null) return null;
        String v = s.toLowerCase(Locale.ROOT).trim();
        for (PokeType t : values()) {
            if (t.id.equals(v) || t.name().equalsIgnoreCase(v) || stripAccents(t.fr).equalsIgnoreCase(stripAccents(v))) return t;
        }
        return null;
    }

    private static String stripAccents(String s) {
        return java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
}
