package fr.cobblepulse.league;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import fr.cobblepulse.command.Cmd;
import fr.cobblepulse.core.Loc;
import fr.cobblepulse.core.Msg;
import fr.cobblepulse.core.Perms;
import fr.cobblepulse.core.TextUtil;
import fr.cobblepulse.core.TimeFmt;
import fr.cobblepulse.data.LeagueData.PostData;
import fr.cobblepulse.gui.Guis;
import fr.cobblepulse.storage.PlayerDataManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** Commandes /league. */
public final class LeagueCommands {
    private LeagueCommands() {}

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(method_9247("league").requires(Perms.playerReq(Perms.LEAGUE_VIEW))
                .executes(ctx -> {
                    LeagueGuis.openLeague(ctx.getSource().method_9207());
                    return 1;
                })
                .then(method_9247("badges").requires(Perms.playerReq(Perms.LEAGUE_BADGES)).executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    LeagueGuis.openBadgeCase(p, p.method_5667(), p.method_7334().getName(), PlayerDataManager.online(p), false);
                    return 1;
                }))
                .then(method_9247("inspect").requires(Perms.staffReq(Perms.STAFF_INSPECT))
                        .then(method_9244("joueur", StringArgumentType.word()).suggests(Cmd.ONLINE).executes(LeagueCommands::inspect)))
                .then(method_9247("challenge")
                        .then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS)
                                .then(method_9247("badge").executes(ctx -> challenge(ctx, LeagueManager.ChallengeType.BADGE)))
                                .then(method_9247("place").executes(ctx -> challenge(ctx, LeagueManager.ChallengeType.PLACE)))))
                .then(method_9247("queue").then(method_9247("leave").executes(ctx -> {
                    LeagueManager.leaveQueue(ctx.getSource().method_9207());
                    return 1;
                })))
                .then(method_9247("accept").executes(ctx -> {
                    LeagueManager.accept(ctx.getSource().method_9207());
                    return 1;
                }))
                .then(method_9247("refuse").executes(ctx -> {
                    LeagueManager.refuse(ctx.getSource().method_9207());
                    return 1;
                }))
                .then(method_9247("arena").executes(ctx -> {
                            LeagueGuis.openHolderMenu(ctx.getSource().method_9207());
                            return 1;
                        })
                        .then(method_9247("settp").requires(Perms.playerReq(Perms.ARENA_SETTP))
                                .then(method_9247("holder").executes(ctx -> holderTp(ctx, true)))
                                .then(method_9247("challenger").executes(ctx -> holderTp(ctx, false))))
                        .then(method_9247("toggle").requires(Perms.playerReq(Perms.ARENA_TOGGLE)).executes(ctx -> {
                            class_3222 p = ctx.getSource().method_9207();
                            PostData post = LeagueManager.postOf(p.method_5667());
                            if (post == null) {
                                Msg.send(p, "league.err_not_holder");
                                return 0;
                            }
                            LeagueManager.setOpen(post, !post.open);
                            Msg.send(p, post.open ? "league.arena_now_open" : "league.arena_now_closed");
                            return 1;
                        })))
                .then(method_9247("resign").executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    PostData post = LeagueManager.postOf(p.method_5667());
                    if (post == null) {
                        Msg.send(p, "league.err_not_holder");
                        return 0;
                    }
                    Guis.confirm(p, "&4Démissionner ?", "Quitter le poste " + LeagueManager.plainName(post),
                            () -> LeagueManager.vacate(post, "league.resigned", true), null);
                    return 1;
                }))
                .then(method_9247("cooldown").requires(Perms.staffReq(Perms.STAFF_COOLDOWN_RESET))
                        .then(method_9247("reset").then(method_9244("joueur", StringArgumentType.word()).suggests(Cmd.ONLINE)
                                .executes(ctx -> resetCooldown(ctx, "all"))
                                .then(method_9244("cible", StringArgumentType.word()).suggests((c, b) -> {
                                    List<String> s = new ArrayList<>(List.of("all", "place"));
                                    LeagueManager.posts().forEach(p -> s.add(p.id));
                                    return class_2172.method_9265(s, b);
                                }).executes(ctx -> resetCooldown(ctx, StringArgumentType.getString(ctx, "cible")))))))
                .then(method_9247("admin").requires(Perms.adminReq(Perms.ADMIN_LEAGUE))
                        .executes(ctx -> {
                            LeagueGuis.openAdmin(ctx.getSource().method_9207());
                            return 1;
                        })
                        .then(method_9247("list").executes(LeagueCommands::list))
                        .then(method_9247("set").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS)
                                .then(method_9244("joueur", StringArgumentType.word()).suggests(Cmd.ONLINE).executes(ctx -> {
                                    PostData post = post(ctx);
                                    if (post == null) return 0;
                                    return Cmd.profile(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), gp -> {
                                        LeagueManager.assign(post, gp.getId(), gp.getName(), true);
                                        Msg.send(ctx.getSource(), "league.admin_assigned", "player", gp.getName(), "post", LeagueManager.plainName(post));
                                    }) ? 1 : 0;
                                }))))
                        .then(method_9247("vacate").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS).executes(ctx -> {
                            PostData post = post(ctx);
                            if (post == null) return 0;
                            LeagueManager.vacate(post, "league.vacated_admin", true);
                            Msg.send(ctx.getSource(), "league.admin_vacated", "post", LeagueManager.plainName(post));
                            return 1;
                        })))
                        .then(method_9247("types").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS)
                                .then(method_9244("type1", StringArgumentType.word()).suggests(Cmd.TYPES).executes(ctx -> types(ctx, false))
                                        .then(method_9244("type2", StringArgumentType.word()).suggests(Cmd.TYPES).executes(ctx -> types(ctx, true))))))
                        .then(method_9247("settp").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS)
                                .then(method_9247("holder").executes(ctx -> adminTp(ctx, true)))
                                .then(method_9247("challenger").executes(ctx -> adminTp(ctx, false)))))
                        .then(method_9247("open").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS).executes(ctx -> setOpen(ctx, true))))
                        .then(method_9247("close").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS).executes(ctx -> setOpen(ctx, false))))
                        .then(method_9247("resetcooldown").then(method_9244("poste", StringArgumentType.word()).suggests(Cmd.POSTS).executes(ctx -> {
                            PostData post = post(ctx);
                            if (post == null) return 0;
                            LeagueManager.resetPostCooldown(post);
                            Msg.send(ctx.getSource(), "league.admin_post_cooldown_reset", "post", LeagueManager.plainName(post));
                            return 1;
                        })))));
    }

    private static PostData post(CommandContext<class_2168> ctx) {
        String id = StringArgumentType.getString(ctx, "poste");
        PostData p = LeagueManager.post(id);
        if (p == null) Msg.send(ctx.getSource(), "league.err_unknown_post", "post", id);
        return p;
    }

    private static int challenge(CommandContext<class_2168> ctx, LeagueManager.ChallengeType type) throws CommandSyntaxException {
        class_3222 p = ctx.getSource().method_9207();
        PostData post = post(ctx);
        if (post == null) return 0;
        LeagueManager.challenge(p, post, type);
        return 1;
    }

    private static int holderTp(CommandContext<class_2168> ctx, boolean holderPoint) throws CommandSyntaxException {
        class_3222 p = ctx.getSource().method_9207();
        PostData post = LeagueManager.postOf(p.method_5667());
        if (post == null) {
            Msg.send(p, "league.err_not_holder");
            return 0;
        }
        LeagueManager.setTp(post, holderPoint, Loc.of(p));
        Msg.send(p, "league.tp_set", "point", holderPoint ? "Titulaire" : "Challenger");
        return 1;
    }

    private static int adminTp(CommandContext<class_2168> ctx, boolean holderPoint) throws CommandSyntaxException {
        class_3222 p = ctx.getSource().method_9207();
        PostData post = post(ctx);
        if (post == null) return 0;
        LeagueManager.setTp(post, holderPoint, Loc.of(p));
        Msg.send(p, "league.tp_set", "point", holderPoint ? "Titulaire" : "Challenger");
        return 1;
    }

    private static int setOpen(CommandContext<class_2168> ctx, boolean open) {
        PostData post = post(ctx);
        if (post == null) return 0;
        LeagueManager.setOpen(post, open);
        Msg.send(ctx.getSource(), open ? "league.arena_now_open" : "league.arena_now_closed");
        return 1;
    }

    private static int types(CommandContext<class_2168> ctx, boolean two) {
        PostData post = post(ctx);
        if (post == null) return 0;
        List<PokeType> types = new ArrayList<>();
        PokeType t1 = PokeType.of(StringArgumentType.getString(ctx, "type1"));
        PokeType t2 = two ? PokeType.of(StringArgumentType.getString(ctx, "type2")) : null;
        if (t1 == null || (two && t2 == null)) {
            Msg.send(ctx.getSource(), "league.err_unknown_type");
            return 0;
        }
        types.add(t1);
        if (t2 != null) types.add(t2);
        int needed = LeagueManager.kind(post).typeCount;
        if (types.size() != needed) {
            Msg.send(ctx.getSource(), "league.err_type_count", "count", needed);
            return 0;
        }
        LeagueManager.setTypes(post, types);
        Msg.send(ctx.getSource(), "league.types_set", "post", LeagueManager.plainName(post));
        return 1;
    }

    private static int inspect(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 viewer = ctx.getSource().method_9207();
        return Cmd.profile(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"),
                gp -> PlayerDataManager.with(gp.getId(), gp.getName(), d -> LeagueGuis.openBadgeCase(viewer, gp.getId(), gp.getName(), d, true))) ? 1 : 0;
    }

    private static int resetCooldown(CommandContext<class_2168> ctx, String target) {
        return Cmd.profile(ctx.getSource(), StringArgumentType.getString(ctx, "joueur"), gp ->
                PlayerDataManager.modify(gp.getId(), gp.getName(), d -> {
                    if (target.equals("all")) {
                        d.badgeCooldowns.clear();
                        d.placeCooldownUntil = 0;
                    } else if (target.equals("place")) {
                        d.placeCooldownUntil = 0;
                    } else {
                        d.badgeCooldowns.remove(target);
                    }
                    Msg.send(ctx.getSource(), "league.cooldown_reset", "player", gp.getName());
                })) ? 1 : 0;
    }

    private static int list(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        for (PostData p : LeagueManager.posts()) {
            long cd = LeagueManager.postCooldownRemaining(p);
            src.method_45068(TextUtil.legacy("&7" + p.id + " &8| " + LeagueManager.displayName(p) + " &8| &f"
                    + (p.holderName == null ? "Vacant" : p.holderName) + " &8| " + (p.open ? "&aouverte" : "&cfermée")
                    + " &8| TP " + (p.tpHolder != null && p.tpChallenger != null ? "&aok" : "&cmanquant")
                    + (cd > 0 ? " &8| &ccooldown " + TimeFmt.duration(cd) : "")));
        }
        return 1;
    }
}
